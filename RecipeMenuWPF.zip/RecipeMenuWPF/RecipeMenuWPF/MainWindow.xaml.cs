﻿using System;
using System.Collections.Generic;
using System.Windows;
using LiveCharts;
using LiveCharts.Wpf;
using System.Windows.Controls;

namespace RecipeMenuWPF
{
    public partial class MainWindow : Window
    {
        private List<Recipe> recipes = new List<Recipe>();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void NewRecipeButton_Click(object sender, RoutedEventArgs e)
        {
           
            string recipeName = RecipeNameTextBox.Text;
            Recipe newRecipe = new Recipe(recipeName);

           
            int ingredientCount;
            if (!int.TryParse(IngredientCountTextBox.Text, out ingredientCount))
            {
                MessageBox.Show("Invalid number of ingredients.");
                return;
            }

           
            for (int i = 0; i < ingredientCount; i++)
            {
                string ingredientName = $"Ingredient {i + 1}";

                

                double quantity;
                if (!double.TryParse(Microsoft.VisualBasic.Interaction.InputBox($"Enter Quantity for {ingredientName}", "Quantity", "0"), out quantity))
                {
                    MessageBox.Show("Invalid quantity entered.");
                    return;
                }

                string unit = Microsoft.VisualBasic.Interaction.InputBox($"Enter Unit for {ingredientName}", "Unit", "cups");

                double calories;
                if (!double.TryParse(Microsoft.VisualBasic.Interaction.InputBox($"Enter Calories for {ingredientName}", "Calories", "0"), out calories))
                {
                    MessageBox.Show("Invalid calories entered.");
                    return;
                }

                string foodGroup = Microsoft.VisualBasic.Interaction.InputBox($"Enter Food Group for {ingredientName}", "Food Group", "Carbohydrates");

                newRecipe.AddIngredient(new Ingredients { Name = ingredientName, Quantity = quantity, Unit = unit, Calories = calories, FoodGroup = foodGroup });
            }

           
            int stepCount;
            if (!int.TryParse(StepCountTextBox.Text, out stepCount))
            {
                MessageBox.Show("Invalid number of steps.");
                return;
            }

            
            for (int i = 0; i < stepCount; i++)
            {
                string stepDescription = Microsoft.VisualBasic.Interaction.InputBox($"Enter Step {i + 1} Description", "Step Description", $"Step {i + 1}");
                newRecipe.AddStep(new Steps { Description = stepDescription });
            }

            
            recipes.Add(newRecipe);
            UpdateRecipeListBox();
            UpdatePieChart();
        }

        private void UpdateRecipeListBox()
        {
            RecipeListBox.Items.Clear();
            foreach (Recipe recipe in recipes)
            {
                RecipeListBox.Items.Add(recipe.Name);
            }
        }

        private void UpdatePieChart()
        {
            Dictionary<string, double> foodGroupPercentages = CalculateFoodGroupPercentages();
            SeriesCollection series = new SeriesCollection();

            foreach (var kvp in foodGroupPercentages)
            {
                series.Add(new PieSeries
                {
                    Title = kvp.Key,
                    Values = new ChartValues<double> { kvp.Value }
                });
            }

            FoodGroupPieChart.Series = series;
            FoodGroupPieChart.LegendLocation = LegendLocation.Right;
        }

        private Dictionary<string, double> CalculateFoodGroupPercentages()
        {
            Dictionary<string, double> foodGroupPercentages = new Dictionary<string, double>
            {
                { "Carbohydrates", 0 },
                { "Proteins", 0 },
                { "Fats", 0 },
                { "Fibre", 0 },
                { "Vitamins", 0 },
                { "Minerals", 0 }
            };

           
            double totalCalories = 0;
            Dictionary<string, double> foodGroupCalories = new Dictionary<string, double>
            {
                { "Carbohydrates", 0 },
                { "Proteins", 0 },
                { "Fats", 0 },
                { "Fibre", 0 },
                { "Vitamins", 0 },
                { "Minerals", 0 }
            };

            foreach (var recipe in recipes)
            {
                foreach (var ingredient in recipe.Ingredients)
                {
                    totalCalories += ingredient.Calories;
                    if (foodGroupCalories.ContainsKey(ingredient.FoodGroup))
                    {
                        foodGroupCalories[ingredient.FoodGroup] += ingredient.Calories;
                    }
                }
            }

            
            foreach (var kvp in foodGroupCalories)
            {
                if (totalCalories > 0)
                {
                    foodGroupPercentages[kvp.Key] = kvp.Value / totalCalories * 100;
                }
            }

            return foodGroupPercentages;
        }
    }
}
