﻿using System.Collections.Generic;

namespace RecipeMenuWPF
{
    public class Recipe
    {
        public string Name { get; set; }
        public List<Ingredients> Ingredients { get; set; }
        public List<Steps> Steps { get; set; }
        private List<Ingredients> OriginalIngredients { get; set; }

        public Recipe(string name)
        {
            Name = name;
            Ingredients = new List<Ingredients>();
            Steps = new List<Steps>();
            OriginalIngredients = new List<Ingredients>();
        }

        public void AddIngredient(Ingredients ingredient)
        {
            Ingredients.Add(ingredient);
            OriginalIngredients.Add(new Ingredients
            {
                Name = ingredient.Name,
                Quantity = ingredient.Quantity,
                Unit = ingredient.Unit,
                Calories = ingredient.Calories,
                FoodGroup = ingredient.FoodGroup
            });
        }

        public void AddStep(Steps step)
        {
            Steps.Add(step);
        }

        public void ScaleRecipe(double factor)
        {
            foreach (var ingredient in Ingredients)
            {
                ingredient.Quantity *= factor;
            }
        }

        public void ResetQuantities()
        {
            for (int i = 0; i < Ingredients.Count; i++)
            {
                Ingredients[i].Quantity = OriginalIngredients[i].Quantity;
            }
        }

        public double CalculateTotalCalories()
        {
            double totalCalories = 0;
            foreach (var ingredient in Ingredients)
            {
                totalCalories += ingredient.Calories;
            }
            return totalCalories;
        }

        public void MarkStepAsCompleted(int stepNumber)
        {
            if (stepNumber >= 1 && stepNumber <= Steps.Count)
            {
                Steps[stepNumber - 1].ToggleCompletion();
            }
        }

        public void Display(bool includeTotalCalories)
        {
            Console.WriteLine($"Recipe: {Name}");
            Console.WriteLine("Ingredients:");
            foreach (var ingredient in Ingredients)
            {
                Console.WriteLine($"{ingredient.Quantity} {ingredient.Unit} of {ingredient.Name}");
            }
            Console.WriteLine("Steps:");
            for (int i = 0; i < Steps.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {Steps[i]}");
            }

            if (includeTotalCalories)
            {
                Console.WriteLine($"Total calories: {CalculateTotalCalories()}");
                if (CalculateTotalCalories() > 300)
                {
                    Console.WriteLine("Warning: This recipe exceeds 300 calories!");
                }
            }
        }
    }
}
