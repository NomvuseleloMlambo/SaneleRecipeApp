﻿using RecipeMenuWPF;
namespace RecipeMenuWPF
{
    public class Steps
    {
        public string Description { get; set; }
        private bool done;
        public bool Done
        {
            get { return done; }
            set { done = value; }
        }

        public Steps()
        {
            Done = false;
        }

        public void ToggleCompletion()
        {
            Done = !Done;
        }

        public override string ToString()
        {
            return $"{(Done ? "[x]" : "[ ]")} {Description}";
        }
    }
}
