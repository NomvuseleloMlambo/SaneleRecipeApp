﻿using System;

namespace SaneleRecipeApp
{
    class Program
    {
        static void Main(string[] args)
        {
            bool continueProgram = true;
            while (continueProgram)
            {
                Recipe recipe = new Recipe();
                recipe.EnterRecipeDetails();
                recipe.DisplayRecipe();

                Console.WriteLine("\nDo you want to scale the recipe? (Y/N)");
                char scaleChoice = char.ToUpper(Console.ReadKey().KeyChar);
                if (scaleChoice == 'Y')
                {
                    Console.WriteLine("\nEnter scaling factor (0.5, 2, or 3): ");
                    double factor;
                    while (!double.TryParse(Console.ReadLine(), System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out factor)
                        || (factor != 0.5 && factor != 2 && factor != 3))
                    {
                        Console.WriteLine("Invalid input. Enter scaling factor (0.5, 2, or 3): ");
                    }
                    recipe.ScaleRecipe(factor);
                    recipe.DisplayRecipe();
                }

                if (scaleChoice == 'N')
                {
                    Console.WriteLine("\nDo you want to reset quantities to original values? (Y/N)");
                    char resetChoice = char.ToUpper(Console.ReadKey().KeyChar);
                    if (resetChoice == 'Y')
                    {
                        recipe.ResetQuantities();
                        Console.WriteLine("\nQuantities reset to original values.");
                        recipe.DisplayRecipe(); // Display the recipe with original quantities
                    }

                    Console.WriteLine("\nDo you want to clear the recipe data? (Y/N)");
                    char clearChoice = char.ToUpper(Console.ReadKey().KeyChar);
                    if (clearChoice == 'Y')
                    {
                        recipe.ClearData();
                    }
                    else
                    {
                        Console.WriteLine("Data not cleared.");
                    }

                    Console.WriteLine("\nDo you want to enter another recipe? (Y/N)");
                    char continueChoice = char.ToUpper(Console.ReadKey().KeyChar);
                    continueProgram = (continueChoice == 'Y');
                }
                else
                {
                    Console.WriteLine("\nDo you want to clear the recipe data? (Y/N)");
                    char clearChoice = char.ToUpper(Console.ReadKey().KeyChar);
                    if (clearChoice == 'Y')
                    {
                        recipe.ClearData();
                    }
                    else
                    {
                        Console.WriteLine("Data not cleared.");
                    }

                    Console.WriteLine("\nDo you want to enter another recipe? (Y/N)");
                    char continueChoice = char.ToUpper(Console.ReadKey().KeyChar);
                    continueProgram = (continueChoice == 'Y');
                }
            }

            Console.WriteLine("\nPress any key to exit...");
            Console.ReadKey();
        }
    }
}




