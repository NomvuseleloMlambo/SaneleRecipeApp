﻿Instructions

1. Open the 'SaneleRecipeApp' file with visual studio.
2. Build the solution.
3. Run the application by clicking on the start button.
4. Follow the command-line prompts to enter recipe details, scale the recipe, reset to original qunatities and clear data

GitHub link
https://github.com/NomvuseleloMlambo/SaneleRecipeApp.git