﻿using System;

namespace SaneleRecipeApp
{
    class Recipe
    {
        private Ingredients[] ingredients;
        private Steps[] steps;
        private double[] originalQuantities; // Store original quantities for reset

        // Constructor to initialize originalQuantities array
        public Recipe()
        {
            originalQuantities = null;
        }

        // Method to enter recipe details
        public void EnterRecipeDetails()
        {
            Console.WriteLine("Enter the details for the recipe:");
            Console.Write("Enter the number of ingredients: ");
            int ingredientCount = int.Parse(Console.ReadLine());

            ingredients = new Ingredients[ingredientCount];
            for (int i = 0; i < ingredientCount; i++)
            {
                Console.WriteLine($"Enter details for ingredient {i + 1}:");
                Console.Write("Name: ");
                string name = Console.ReadLine();
                Console.Write("Quantity: ");
                double quantity = double.Parse(Console.ReadLine());
                Console.Write("Unit: ");
                string unit = Console.ReadLine();

                ingredients[i] = new Ingredients { Name = name, Quantity = quantity, Unit = unit };
            }

            // Store original quantities for reset
            originalQuantities = new double[ingredientCount];
            for (int i = 0; i < ingredientCount; i++)
            {
                originalQuantities[i] = ingredients[i].Quantity;
            }

            Console.Write("Enter the number of steps: ");
            int stepCount = int.Parse(Console.ReadLine());

            steps = new Steps[stepCount];
            for (int i = 0; i < stepCount; i++)
            {
                Console.WriteLine($"Enter step {i + 1}:");
                string description = Console.ReadLine();
                steps[i] = new Steps { Description = description };
            }
        }

        // Method to display the recipe
        public void DisplayRecipe()
        {
            Console.WriteLine("\nRecipe Details:");
            Console.WriteLine("Ingredients:");
            foreach (var ingredient in ingredients)
            {
                Console.WriteLine($"{ingredient.Quantity} {ingredient.Unit} of {ingredient.Name}");
            }

            Console.WriteLine("\nSteps:");
            for (int i = 0; i < steps.Length; i++)
            {
                Console.WriteLine($"{i + 1}. {steps[i].Description}");
            }
        }

        // Method to scale the recipe by a factor
        public void ScaleRecipe(double factor)
        {
            foreach (var ingredient in ingredients)
            {
                ingredient.Quantity *= factor;
            }
        }

        // Method to reset ingredient quantities to their original values
        public void ResetQuantities()
        {
            if (originalQuantities != null)
            {
                // Loop through all ingredients to reset their quantities
                for (int i = 0; i < ingredients.Length; i++)
                {
                    ingredients[i].Quantity = originalQuantities[i]; 
                }
                Console.WriteLine("\nQuantities reset to original values."); 
            }
            else
            {
                Console.WriteLine("\nNo original quantities to reset."); 
            }
        }

        // Method to clear all data (ingredients, steps, and original quantities)
        public void ClearData()
        {
            ingredients = null;
            steps = null;
            originalQuantities = null;
        }
    }
}


