﻿namespace SaneleRecipeApp
{
    class Steps
    {
        public string Description { get; set; }
    }
}
