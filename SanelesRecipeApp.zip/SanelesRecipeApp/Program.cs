﻿using SanelesRecipeApp;
using System;
using System.Collections.Generic;

namespace SSanelesRecipeApp
{
    class Recipe
    {
        public string Name { get; set; }
        private List<Ingredients> ingredients;
        private List<Steps> steps;
        private List<double> originalQuantities; // Store original quantities for reset

        // Define a delegate for notifying high calorie recipes
        public delegate void CalorieAlertHandler(string recipeName, double totalCalories);
        public event CalorieAlertHandler OnHighCalorieRecipe;

        // Constructor to initialize lists
        public Recipe()
        {
            ingredients = new List<Ingredients>();
            steps = new List<Steps>();
            originalQuantities = new List<double>();
        }

        // Method to enter recipe details
        public void EnterRecipeDetails()
        {
            Console.WriteLine("Enter the name of the recipe:");
            Name = Console.ReadLine();

            Console.WriteLine("Enter the details for the recipe:");
            Console.Write("Enter the number of ingredients: ");
            int ingredientCount = int.Parse(Console.ReadLine());

            for (int i = 0; i < ingredientCount; i++)
            {
                Console.WriteLine($"Enter details for ingredient {i + 1}:");
                Console.Write("Name: ");
                string name = Console.ReadLine();
                Console.Write("Quantity: ");
                double quantity = double.Parse(Console.ReadLine());
                Console.Write("Unit: ");
                string unit = Console.ReadLine();
                Console.Write("Calories: ");
                double calories = double.Parse(Console.ReadLine());
                Console.Write("Food Group: ");
                string foodGroup = Console.ReadLine();

                ingredients.Add(new Ingredients
                {
                    Name = name,
                    Quantity = quantity,
                    Unit = unit,
                    Calories = calories,
                    FoodGroup = foodGroup
                });

                // Store original quantities for reset
                originalQuantities.Add(quantity);
            }

            Console.Write("Enter the number of steps: ");
            int stepCount = int.Parse(Console.ReadLine());

            for (int i = 0; i < stepCount; i++)
            {
                Console.WriteLine($"Enter step {i + 1}:");
                string description = Console.ReadLine();
                steps.Add(new Steps { Description = description });
            }
        }

        // Method to calculate total calories
        public double CalculateTotalCalories()
        {
            double totalCalories = 0;
            foreach (var ingredient in ingredients)
            {
                totalCalories += ingredient.Calories;
            }

            // Check if total calories exceed 300 and trigger the delegate
            if (totalCalories > 300)
            {
                OnHighCalorieRecipe?.Invoke(Name, totalCalories);
            }

            return totalCalories;
        }

        // Method to display the recipe

        public void DisplayRecipe()
        {
            Console.WriteLine($"\nRecipe: {Name}");
            Console.WriteLine("Ingredients:");
            foreach (var ingredient in ingredients)
            {
                Console.WriteLine($"{ingredient.Quantity} {ingredient.Unit} of {ingredient.Name} - {ingredient.Calories} calories, {ingredient.FoodGroup}");
            }

            Console.WriteLine("\nSteps:");
            for (int i = 0; i < steps.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {steps[i].Description}");
            }

            // Display total calories
            Console.WriteLine($"\nTotal Calories: {CalculateTotalCalories()}");
        }

        // Method to scale the recipe by a factor
        public void ScaleRecipe(double factor)
        {
            for (int i = 0; i < ingredients.Count; i++)
            {
                ingredients[i].Quantity *= factor;
            }
        }

        // Method to reset ingredient quantities to their original values
        public void ResetQuantities()
        {
            for (int i = 0; i < ingredients.Count; i++)
            {
                ingredients[i].Quantity = originalQuantities[i];
            }
            Console.WriteLine("\nQuantities reset to original values.");
        }

        // Method to clear all data (ingredients, steps, and original quantities)
        public void ClearData()
        {
            ingredients.Clear();
            steps.Clear();
            originalQuantities.Clear();
        }
    }
}