﻿Usage Instructions

Main Menu
After starting the application, you will be presented with the main menu with the following options:

1. Enter a New Recipe
2. Recipe Display Menu
3. Exit

Adding a New Recipe

1. Select "Enter a New Recipe" from the main menu.
2. Enter the name of the recipe.
3. Enter the number of ingredients.
3. For each ingredient, provide:
   Name
   Quantity
   Unit (e.g., grams, tablespoons)
   Calories
   Food group (select from Carbohydrates, Fats, Fibre, Minerals, Proteins, Vitamins, Water)
4. Enter the number of steps.
5. For each step, provide a description.
6. You will have an option to scale your ingredients as many times as posibble.
7. You can also reset the original ingredient quantities.
8. You also have the option to clear recipe data.

Recipe Display Menu

Select "Recipe Display Menu" from the main menu.
The following options will be available:
1. Display All Recipes
2. Display a Specific Recipe
3. Return to Main Menu

Displaying All Recipes

1. Select "Display All Recipes" from the recipe display menu.
2. The application will list all recipes in alphabetical order by name.

Displaying a Specific Recipe

Select "Display a Specific Recipe" from the recipe display menu.
1. Choose a recipe from the list of all recipes.
3. The application will display the full details of the recipe including ingredients and steps.

Returning to Main Menu

1. Select "Return to Main Menu" from the recipe display menu.
2. The application will return to the main menu.

Exiting the Application

1. Select "Exit" from the main menu.
2. The application will close.

Additional Information
1. The program uses delegates to notify users about calorie limits.
2. Recipes and ingredients are managed using generic collections.

GitHub
Updates

In the second part of the application, many changes were implemented to enhance user experience and functionality. One notable change is the ability for users to add an unlimited number of recipes, catering to diverse culinary interests and preferences. Additionally, users can now specify unique names for each recipe they add, allowing for better organization and easier retrieval. Another key improvement is the introduction of generic collections instead of arrays to store recipe-related data such as ingredients and steps. This change not only optimizes data management but also facilitates scalability and future enhancements. Furthermore, users now have the flexibility to choose which recipe they want to display, providing a more personalized and tailored browsing experience. The user can now scale the ingredients as many times as possible. The values can also be reset to original values. I also added more comments and made the readme file more comprehensive. 

