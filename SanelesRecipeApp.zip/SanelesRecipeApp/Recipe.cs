﻿using SanelesRecipeApp;
using System;
using System.Collections.Generic;

namespace SaneleRecipeApp
{
    class Recipe
    {
        public string Name { get; set; }
        private List<Ingredients> ingredients;
        private List<Steps> steps;
        private List<double> originalQuantities;
        public event Action<string, double> OnHighCalorieRecipe;

        public Recipe()
        {
            ingredients = new List<Ingredients>();
            steps = new List<Steps>();
            originalQuantities = new List<double>();
        }

        public void EnterRecipeDetails()
        {
            Console.Write("Enter the name of the recipe: ");
            Name = Console.ReadLine();

            Console.Write("Enter the number of ingredients: ");
            int ingredientCount = int.Parse(Console.ReadLine());

            for (int i = 0; i < ingredientCount; i++)
            {
                Console.WriteLine($"Enter details for ingredient {i + 1}:");
                Console.Write("Name: ");
                string name = Console.ReadLine();
                Console.Write("Quantity: ");
                double quantity = double.Parse(Console.ReadLine());
                Console.Write("Unit: ");
                string unit = Console.ReadLine();
                Console.Write("Calories: ");
                double calories = double.Parse(Console.ReadLine());

                string foodGroup = SelectFoodGroup();

                ingredients.Add(new Ingredients
                {
                    Name = name,
                    Quantity = quantity,
                    Unit = unit,
                    Calories = calories,
                    FoodGroup = foodGroup
                });
                originalQuantities.Add(quantity);
            }

            Console.Write("Enter the number of steps: ");
            int stepCount = int.Parse(Console.ReadLine());

            for (int i = 0; i < stepCount; i++)
            {
                Console.WriteLine($"Enter step {i + 1}:");
                string description = Console.ReadLine();
                steps.Add(new Steps { Description = description });
            }

            double totalCalories = CalculateTotalCalories();
            if (totalCalories > 300)
            {
                OnHighCalorieRecipe?.Invoke(Name, totalCalories);
            }
        }

        private string SelectFoodGroup()
        {
            Console.WriteLine("Select the food group:");
            Console.WriteLine("1. Carbohydrates");
            Console.WriteLine("2. Fats");
            Console.WriteLine("3. Fibre");
            Console.WriteLine("4. Minerals");
            Console.WriteLine("5. Proteins");
            Console.WriteLine("6. Vitamins");
            Console.WriteLine("7. Water");
            Console.Write("Enter your choice (1-7): ");
            string choice = Console.ReadLine();

            return choice switch
            {
                "1" => "Carbohydrates",
                "2" => "Fats",
                "3" => "Fibre",
                "4" => "Minerals",
                "5" => "Proteins",
                "6" => "Vitamins",
                "7" => "Water",
                _ => throw new ArgumentException("Invalid choice")
            };
        }

        public void DisplayRecipe()
        {
            Console.WriteLine($"\nRecipe: {Name}");
            Console.WriteLine("Ingredients:");
            foreach (var ingredient in ingredients)
            {
                Console.WriteLine($"{ingredient.Quantity} {ingredient.Unit} of {ingredient.Name} ({ingredient.Calories} calories, {ingredient.FoodGroup})");
            }

            Console.WriteLine("\nSteps:");
            for (int i = 0; i < steps.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {steps[i].Description}");
            }
        }

        public void ScaleRecipe(double factor)
        {
            for (int i = 0; i < ingredients.Count; i++)
            {
                ingredients[i].Quantity *= factor;
            }
        }

        public void ResetQuantities()
        {
            for (int i = 0; i < ingredients.Count; i++)
            {
                ingredients[i].Quantity = originalQuantities[i];
            }
            Console.WriteLine("\nQuantities reset to original values.");
        }

        public void ClearData()
        {
            ingredients.Clear();
            steps.Clear();
            originalQuantities.Clear();
        }

        private double CalculateTotalCalories()
        {
            double totalCalories = 0;
            foreach (var ingredient in ingredients)
            {
                totalCalories += ingredient.Calories;
            }
            return totalCalories;
        }
    }
}
