﻿namespace SanelesRecipeApp
{
    class Steps
    {
        public string Description { get; set; }
    }
}
